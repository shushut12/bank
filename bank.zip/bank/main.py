n = "bank.txt"
with open(n, "r") as file:
    lines = file.readlines()
    num_of_lines = int(len(lines))
m = int(lines[num_of_lines - 1])
f = open('bank.txt', 'a')
a = int(input('Введите функцию:'))  # 0-история,1-положить деньги,2-снять деньги
if a == 1:
    z = int(input("Положить деньги:"))
    m = m + z
    f.write(str(m) + "\n")
elif a == 2:
    x = int(input('Снять деньги:'))
    if m < x:
        print('Ошибка')
    else:
        m = m - x
        f.write(str(m) + "\n")
if a==0:
    f = open('bank.txt', 'r')
    print(*f)